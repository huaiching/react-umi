import React, { useRef } from 'react';
import ProForm, { ProFormDatePicker, ProFormInstance } from '@ant-design/pro-form';

const MyForm: React.FC = () => {
    const formRef = useRef<ProFormInstance>()

    return (
        <>
            <h1>ProFormDatePicker</h1>
            <ProForm
                grid
                layout='vertical'
                formRef={formRef}
                submitter={false}
            >
                <ProFormDatePicker
                    name="date"
                    label="選擇日期"
                    placeholder="請選擇日期"
                    rules={[
                        { required: true, message: '日期為必填項' },
                    ]}
                    fieldProps={{
                        format: 'YYYY/MM/DD'
                    }}
                />
            </ProForm>
        </>
    );
};

export default MyForm;