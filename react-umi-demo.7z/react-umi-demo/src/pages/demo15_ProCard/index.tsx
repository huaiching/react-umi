import ProCard from '@ant-design/pro-card';
import ProForm, { ProFormInstance, ProFormSwitch, ProFormText } from '@ant-design/pro-form';
import { Button } from 'antd';
import React, { useEffect, useRef, useState } from 'react';

const InsurancePolicyCard: React.FC = () => {
    const formRef = useRef<ProFormInstance>()
    const [poEdit, setPoEdit] = useState<Boolean>(false)

    useEffect(()=>{
        formRef.current?.setFieldsValue({
            policyNo: '1234567890',
            poStsCode: '42',
        })
    },[])

    return (
        <ProForm
            grid
            layout="vertical"
            formRef={formRef}
            submitter={false}
        >
            <ProCard 
                title="保單資訊" 
                type='default' 
                size='default' 
                headerBordered
                // collapsible
                // defaultCollapsed
                extra={
                    <ProFormSwitch
                        name="poStatus"
                        fieldProps={{
                            checkedChildren: '編輯',
                            unCheckedChildren: '關閉',
                            onChange: setPoEdit
                        }}
                    />
                }
            >
                <ProFormText
                    name="policyNo"
                    label="保單號碼"
                    readonly={!poEdit}
                />
                <ProFormText
                    name="poStsCode"
                    label="保單狀態"
                    readonly={!poEdit}
                />
            </ProCard>
            <Button 
                type='primary'
                onClick={() => {
                    console.log('formRef',formRef.current?.getFieldsValue())
                }}
            >檢視數據</Button>
        </ProForm>
    );
};

export default InsurancePolicyCard;
