export const editOption: any[] = [
    {
        label: '唯讀',
        value: 'readonly',
    },
    {
        label: '編輯',
        value: 'edit',
    },
]