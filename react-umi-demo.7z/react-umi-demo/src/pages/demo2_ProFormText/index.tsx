import ProForm, { ProFormInstance, ProFormText } from '@ant-design/pro-form';
import React, { useRef } from 'react';

const MyForm: React.FC = () => {
    const formRef = useRef<ProFormInstance>()

    return (
        <>
            <h1>ProFormText</h1>
            <ProForm
                grid
                layout="vertical"
                formRef={formRef}
                submitter={false}
            >
                <ProFormText
                    name="username"
                    label="用戶名稱"
                    tooltip="這是用戶名稱"
                    placeholder="請輸入用戶名稱"
                    colProps={{
                        span: 6                    
                    }}
                    rules={[
                        {
                            required: true,
                            message: '用戶名稱為必填項',
                        },
                    ]}
                    fieldProps={{
                        maxLength: 20
                    }}
                />
            </ProForm>
        </>
    )
};

export default MyForm;
