import Demo2 from "./demo2_ProFormText";
import Demo3 from "./demo3_ProFormTextArea";
import Demo4 from "./demo4_ProFormSelect";
import Demo5 from "./demo5_ProFormDatePicker";
import Demo6 from "./demo6_ProFormTimePicker";
import Demo7 from "./demo7_ProFormSwitch";
import Demo8 from "./demo8_ProFormRadio";
import Demo9 from "./demo9_ProFormCheckbox";
import Demo10 from "./demo10_ProFormUploadButton";
import Demo11 from "./demo11_ProTable";


export default function IndexPage() {
  return (
    <div>
      <Demo11/>
    </div>
  );
}
