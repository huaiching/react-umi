# umi project

## Getting Started

Install dependencies,

```bash
$ yarn
```

Start the dev server,

```bash
$ yarn start
```

umijs 3
https://v3.umijs.org/zh-CN/docs/getting-started



1. 先找個地方建個空目錄
   >>mkdir myapp && cd myapp
2. 通過官方工具創建專案
   >> npx @umijs/create-umi-app  --template=ant-design-pro
3. 修改 package.json 
   >>於 start 加上 「set NODE_OPTIONS=--openssl-legacy-provider && 」
4. 下載依賴 
   >> yarn install
5. 安裝 antd 相關依賴
   >> yarn add antd@4 @ant-design/pro-layout@6 @ant-design/pro-table@2 @ant-design/pro-form@1 @ant-design/pro-card@1 @ant-design/pro-descriptions@1 @ant-design/icons@4